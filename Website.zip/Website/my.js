$(document).ready(function() {
    $('#demo').carousel();
  });
  $('.carousel').carousel()
